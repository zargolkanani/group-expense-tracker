# group-expense-tracker
A simple web application to track shared expenses among friends or group members. Built with React for the frontend and Express for the backend. Calculates each member’s balance and displays who owes or is owed money.
