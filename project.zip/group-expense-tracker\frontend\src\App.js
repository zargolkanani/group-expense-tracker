import { useState, useEffect } from "react";

function App() {
  const [paidBy, setPaidBy] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [balances, setBalances] = useState([]);

  const sendExpense = async () => {
    const res = await fetch("/api/expense", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ paidBy, amount: Number(amount), description })
    });

    const data = await res.json();
    setBalances(data);
  };

  useEffect(() => {
    fetch("/api/balance")
      .then(res => res.json())
      .then(data => setBalances(data));
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h2>ثبت هزینه</h2>

      <input placeholder="نام پرداخت‌کننده"
             value={paidBy} onChange={e => setPaidBy(e.target.value)} />

      <input placeholder="مبلغ"
             type="number"
             value={amount} onChange={e => setAmount(e.target.value)} />

      <input placeholder="توضیح"
             value={description} onChange={e => setDescription(e.target.value)} />

      <button onClick={sendExpense}>ثبت هزینه</button>

      <h2>بدهی / طلبی</h2>
      {balances.map(item => (
        <p key={item.person}>
          {item.person}: {item.balance}
        </p>
      ))}
    </div>
  );
}

export default App;
