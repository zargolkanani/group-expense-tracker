const express = require("express");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

let expenses = [];

app.post("/api/expense", (req, res) => {
  const { paidBy, amount, description, members } = req.body;

  if (!paidBy || !amount || !description || !members || members.length < 1) {
    return res.status(400).json({ error: "اطلاعات ناقص است" });
  }

  expenses.push({ paidBy, amount, description, members });

  let debts = [];

  // محاسبه دقیق سهم هر هزینه
  expenses.forEach(e => {
    // اگر پرداخت‌کننده در اعضا نبود، اضافه می‌کنیم
    let membersList = e.members.includes(e.paidBy) ? e.members : [e.paidBy, ...e.members];

    const share = +(e.amount / membersList.length).toFixed(2);

    membersList.forEach(m => {
      if(m !== e.paidBy){
        debts.push({ from: m, to: e.paidBy, amount: share });
      }
    });
  });

  const output = debts.map(d => `${d.from} باید به ${d.to} ${d.amount} بدهد`);
  const summary = `${paidBy} ${amount} تومان برای ${description} پرداخت کرد`;

  res.json({ summary, debts: output });
});

app.listen(5000, () => console.log("Backend running on port 5000"));
